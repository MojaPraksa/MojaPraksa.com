import React from 'react';
import "../styles.css"

const ApplyForm = ({ companyId }) => {
    const handleSubmit = async (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        formData.append("companyId", companyId);
        try {
            const response = await fetch("http://localhost:5000/api/email/apply", {
                method: "POST",
                body: formData,
            });

            if (response.ok) {
                alert("Prijava uspješno poslana!");
            } else {
                alert("Greška pri slanju prijave!");
            }
        } catch (error) {
            alert("Došlo je do greške!");
        }
    };

    return (
        <div className="apply-form-container">
            <h2>Prijavi se za praksu</h2>
            <form onSubmit={handleSubmit} encType="multipart/form-data">
                {/* ✅ Ispravljeno ovdje */}
                <input type="hidden" name="companyId" value={companyId} />

                <div>
                    <input
                        type="text"
                        name="name"
                        placeholder="Ime"
                        required
                        className="form-input"
                    />
                </div>
                <div>
                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        required
                        className="form-input"
                    />
                </div>
                <div>
                    <label>CV:</label>
                    <input
                        type="file"
                        name="cv"
                        required
                        className="form-input"
                    />
                </div>
                <div>
                    <label>Motivaciono pismo:</label>
                    <input
                        type="file"
                        name="motivation"
                        required
                        className="form-input"
                    />
                </div>
                <div>
                    <button type="submit">Prijavi se</button>
                </div>
            </form>
        </div>
    );
};

export default ApplyForm;
