import React, { useState, useEffect } from "react";

const Quiz = ({ setResults }) => {
    const [questions, setQuestions] = useState([]);
    const [answers, setAnswers] = useState({});

    useEffect(() => {
        fetch("http://localhost:5000/api/questions")
            .then(res => res.json())
            .then(data => setQuestions(data));
    }, []);

    const handleAnswerSelect = (qId, answer) => {
        setAnswers(prev => ({ ...prev, [qId]: answer }));
    };

    const handleSubmit = () => {
        fetch("http://localhost:5000/api/questions/submit", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ answers })
        })
            .then(res => res.json())
            .then(data => setResults(data));
    };

    return (
        <div className="quiz-container">
            <h1>Da li je IT prava karijera za vas?</h1>
            <p>Jeste li se ikada zapitali koliko ste skloni radu u IT sektoru? Naš brzi test IT sklonosti osmišljen je kako bi vam pomogao da prepoznate svoje vještine i način razmišljanja koji su ključni za uspjeh u ovom dinamičnom području. Kroz 15 pažljivo odabranih pitanja procijenit ćemo vaš logički način razmišljanja, analitičke sposobnosti i interes za tehnologiju.</p>
            <div className="quiz-questions">
                {questions.map(q => (
                    <div key={q._id} className="question">
                        <p className="question-text">{q.pitanje}</p>
                        {q.odgovori.map((odg, idx) => (
                            <button
                                key={idx}
                                className={`answer-btn ${answers[q._id] === odg ? "selected" : ""}`}
                                onClick={() => handleAnswerSelect(q._id, odg)}
                            >
                                {odg}
                            </button>
                        ))}
                    </div>
                ))}
                <button className="submit-btn" onClick={handleSubmit}>
                    Pošalji odgovore
                </button>
            </div>

        </div>
    );
};

export default Quiz;
