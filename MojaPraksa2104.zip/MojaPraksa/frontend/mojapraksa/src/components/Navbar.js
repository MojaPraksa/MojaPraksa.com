import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import logo from "../assets/MojaPraksa.png";

const Navbar = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(!!sessionStorage.getItem("token")); // <- zamijenjeno
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = () => {
      const token = sessionStorage.getItem("token");
      setIsAuthenticated(!!token);
      if (token) {
        try {
          const decoded = jwtDecode(token);
          setIsAdmin(decoded.role === "admin");
        } catch (err) {
          console.error("Greška pri dekodiranju tokena:", err);
          setIsAdmin(false);
        }
      } else {
        setIsAdmin(false);
      }
    };

    checkAuth();

    window.addEventListener("storage", checkAuth);
    window.addEventListener("login-success", checkAuth); // <- OVDJE dodaj

    return () => {
      window.removeEventListener("storage", checkAuth);
      window.removeEventListener("login-success", checkAuth); // <- I OVDJE
    };
  }, []);


  const handleLogout = () => {
    sessionStorage.removeItem("token"); // <- zamijenjeno
    sessionStorage.removeItem("userId"); // <- zamijenjeno
    setIsAuthenticated(false);
    setIsAdmin(false);
    window.dispatchEvent(new Event("storage"));
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <div
        className="logo-container"
        onClick={() => {
          if (!isAuthenticated) {
            navigate("/");
          } else if (isAdmin) {
            navigate("/admin");
          } else {
            navigate("/MyEntries");
          }
        }}
        style={{ cursor: "pointer" }}
      >
        <img src={logo} alt="MojaPraksa Logo" className="logo" />
        <span className="logo-text">
          <span className="moja">Moja</span> <span className="praksa">praksa</span>
        </span>
      </div>


      <div className="nav-links">
        {!isAuthenticated ? (
          <>
            <Link to="/kviz" className="nav-pill">
              Testirajte svoje IT sklonosti
            </Link>
            <Link to="/login">
              <button className="login-btn">Prijava</button>
            </Link>
          </>
        ) : (
          <>
            {!isAdmin && (
              <>
                <Link to="/EntryForm" className="nav-pill">
                  Dodaj novi unos
                </Link>
                <Link to="/MyEntries" className="nav-pill">
                  Moji unosi
                </Link>
              </>
            )}
            <button className="login-btn" onClick={handleLogout}>
              Odjava
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
