import React from "react";
import "../styles.css";

const ONama = () => {
  return (
    <div className="onama-section">
      <div className="onama-container">
        <h2>O nama</h2>
        <p>
     Dobrodošli na <strong> Moja Praksa</strong> - platformu koja povezuje studente
     i poslodavce na putu ka stvarnim iskustvima. Naš tim čine mladi, motivisani
     pojedinci iz oblasti programiranja, dizajna i menadžmenta, a zajedno dijelimo
     jednu viziju: da stručna praksa postane više od obične formalnosti.
      Znamo koliko je teško napraviti prve korake u karijeri – zato želimo biti
      most između vašeg znanja i svijeta stvarnog rada. Na ovoj platformi studenti
      mogu pronaći firme za praksu, prijaviti se, voditi dnevnik rada i čak se
      zabaviti kroz kviz kompetencija koji pomaže pri boljem usmjeravanju karijere.
     Mi ne gradimo samo aplikaciju – gradimo zajednicu. Mjesto gdje iskustva
     bivših praktikanata postaju inspiracija novima. Gdje poslodavci pronalaze
     mlade talente. I gdje ti imaš priliku zablistati.
</p>

      </div>
    </div>
  );
};

export default ONama;
