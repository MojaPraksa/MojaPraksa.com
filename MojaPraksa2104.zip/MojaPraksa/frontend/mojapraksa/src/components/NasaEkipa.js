import React, { useEffect, useRef, useState } from "react";
import "../styles.css";

const NasaEkipa = () => {
  const sekcijaRef = useRef();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect(); // Zaustavi dalje posmatranje
        }
      },
      { threshold: 0.3 }
    );

    if (sekcijaRef.current) {
      observer.observe(sekcijaRef.current);
    }

    return () => {
      if (sekcijaRef.current) observer.unobserve(sekcijaRef.current);
    };
  }, []);

  return (
    <section
      ref={sekcijaRef}
      className={`ekipa-section ${visible ? "ekipa-visible" : ""}`}
    >
      <h2>Naš Tim</h2>
      <div className="ekipa-grid">
        <div className="clan-tima">
          <h3>Amra Drijenčić</h3>
          <p>Student Politehničkog fakulteta</p>
        </div>
        <div className="clan-tima">
          <h3>Samina Dubravac</h3>
          <p>Student Politehničkog fakulteta</p>
        </div>
        <div className="clan-tima">
          <h3>Nadina Muračević</h3>
          <p>Student Politehničkog fakulteta</p>
        </div>
        <div className="clan-tima">
          <h3>Sumeja Čoloman</h3>
          <p>Student Politehničkog fakulteta</p>
        </div>
        <div className="clan-tima">
          <h3>Abdullah Awad</h3>
          <p>Student Politehničkog fakulteta</p>
        </div>
        <div className="clan-tima">
          <h3>Nedim Hasić</h3>
          <p>Student Politehničkog fakulteta</p>
        </div>
      </div>
    </section>
  );
};

export default NasaEkipa;
