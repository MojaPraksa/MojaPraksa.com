import React from "react";

const Results = ({ results, resetQuiz }) => {
    return (
        <div className="rezultati">
            <h2>Vaš rezultat:</h2>
            <p><strong>Osvojili ste {results.correctCount} bodova.</strong></p>
            <h3><strong>{results.resultTitle}</strong></h3>
            <p>{results.resultDescription}</p>
            <button className="povratak-btn" onClick={resetQuiz}>Povratak</button>
        </div>
    );
};

export default Results;
