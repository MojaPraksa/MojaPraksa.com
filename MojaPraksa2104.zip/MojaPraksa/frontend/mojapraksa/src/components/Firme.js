import React from "react";
import { Link } from 'react-router-dom';
import "../styles.css";

const Firme = ({ companies }) => {
  return (
    <section className="partneri">
      <h2>Partneri koji oblikuju budućnost</h2>
      <div className="firma-grid">
        {companies.map((company) => (
          <div key={company._id} className="firma-card">
            <Link to={`/company/${company._id}`} className="firma-card-link">
              <img
                src={`http://localhost:5000${company.logo}`}
                alt={company.name}
                className="company-logos"
              />
              <h3>{company.name}</h3>
              <p>{company.about}</p>
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Firme;
