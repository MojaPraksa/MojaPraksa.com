import React, { useEffect, useState } from 'react';
import axios from 'axios';

const InternsList = ({ companyId }) => {
    const [interns, setInterns] = useState([]);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        setError(null);  // Reset error state before fetching data
        axios.get(`http://localhost:5000/api/interns/${companyId}`)
            .then(response => {
                setInterns(response.data);
                setLoading(false);
            })
            .catch(error => {
                setError('Ne možemo učitati listu praktikanata. Pokušajte ponovo.');
                setLoading(false);
            });
    }, [companyId]);

    if (loading) {
        return <div>Učitavanje...</div>;
    }

    if (error) {
        return <div>{error}</div>;
    }

    return (
        <div className="interns-list-container">
            <h2>Praktikanti koji su obavljali praksu u firmi</h2> {/* Naslov na vrhu */}
            <div className="interns-list">
                {interns.length === 0 ? (
                    <p>Nema dostupnih praktikanta.</p>
                ) : (
                    interns.map(({ _id, name, experience, email }) => (
                        <div className="intern-card" key={_id}>
                            <h3>{name}</h3>
                            <p><strong>Pozicija:</strong> {experience}</p>
                            <p><strong>Email:</strong> {email}</p>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default InternsList;
