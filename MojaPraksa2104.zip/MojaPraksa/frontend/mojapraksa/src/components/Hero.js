import React from "react";
import "../styles.css";

const Hero = () => {
  const scrollToPartneri = () => {
    const firmeSection = document.getElementById("firme");
    if (firmeSection) {
      firmeSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="hero-section">
      <header className="hero">
        <div className="hero-overlay">
          <h1>Dobro došli na <span className="highlight">Moju Praksu!</span></h1>
          <p>
            Ovdje kreiramo most između obrazovanja i karijere. Naša platforma omogućava studentima da se povežu s firmama, stiču
            dragocjeno radno iskustvo i razvijaju svoje kompetencije kroz praktičan rad.
          </p>
          <button className="hero-btn" onClick={scrollToPartneri}>Saznaj više</button>
        </div>
      </header>
    </section>
  );
};

export default Hero;
