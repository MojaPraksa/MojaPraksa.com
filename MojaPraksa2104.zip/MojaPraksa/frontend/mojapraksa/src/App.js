import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Kviz from "./pages/Kviz";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import EntryForm from "./pages/EntryForm";
import MyEntries from "./pages/MyEntries"; // Dodaj MyEntries komponentu
import CompanyPage from './pages/CompanyPage';
import EditEntry from "./pages/EditEntry";
import AdminPage from "./pages/AdminPage"; // Dodano

const PrivateRoute = ({ children }) => {
  const token = sessionStorage.getItem("token"); // umjesto localStorage
  return token ? children : <Navigate to="/login" />;
};

const App = () => (
  <BrowserRouter>
    <Navbar /> {/* Navbar je samo ovde */}
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/kviz" element={<Kviz />} />
      <Route path="/login" element={<Login />} />
      <Route path="/EntryForm" element={<PrivateRoute><EntryForm /></PrivateRoute>} />
      <Route path="/MyEntries" element={<PrivateRoute><MyEntries /></PrivateRoute>} />
      <Route path="/company/:id" element={<CompanyPage />} /> {/* Proveri ovo */}
      <Route path="/edit-entry/:id" element={<PrivateRoute><EditEntry /></PrivateRoute>} />
      <Route path="/admin" element={<PrivateRoute><AdminPage /></PrivateRoute>} /> {/* Nova admin ruta */}
    </Routes>
  </BrowserRouter>
);

export default App;
