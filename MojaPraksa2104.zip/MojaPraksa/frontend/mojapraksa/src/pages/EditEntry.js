import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const EditEntry = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        date: "",
        activity: "",
        description: "",
        arrivalTime: "",
        departureTime: ""
    });

    useEffect(() => {
        const fetchEntry = async () => {
            try {
                // ...
                const res = await axios.get(`http://localhost:5000/api/entries/${sessionStorage.getItem("userId")}`);
                // ...
                const entry = res.data.find((e) => e._id === id);
                if (entry) setFormData(entry);
            } catch (error) {
                console.error("Greška pri dohvaćanju unosa:", error);
            }
        };
        fetchEntry();
    }, [id]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.put(`http://localhost:5000/api/entries/${id}`, formData);
            alert("Unos uspješno ažuriran!");
            navigate("/MyEntries");
        } catch (error) {
            console.error("Greška pri ažuriranju unosa:", error);
        }
    };

    return (
        <div className="entry-form-container">
            <div className="form-box">
                <h2>Uredi Unos</h2>
                <form onSubmit={handleSubmit} className="form">
                    <div className="form-field">
                        <label>Datum:</label>
                        <input type="date" name="date" value={formData.date?.slice(0, 10)} onChange={handleChange} required />
                    </div>
                    <div className="form-field">
                        <label>Aktivnost:</label>
                        <input type="text" name="activity" value={formData.activity} onChange={handleChange} required />
                    </div>
                    <div className="form-field">
                        <label>Opis:</label>
                        <textarea name="description" value={formData.description} onChange={handleChange}></textarea>
                    </div>
                    <div className="form-fields-group">
                        <div className="form-field">
                            <label>Vrijeme dolaska:</label>
                            <input type="time" name="arrivalTime" value={formData.arrivalTime} onChange={handleChange} required />
                        </div>
                        <div className="form-field">
                            <label>Vrijeme odlaska:</label>
                            <input type="time" name="departureTime" value={formData.departureTime} onChange={handleChange} required />
                        </div>
                    </div>
                    <button type="submit" className="submit-button">Ažuriraj unos</button>
                </form>
            </div>
        </div>
    );
};

export default EditEntry;
