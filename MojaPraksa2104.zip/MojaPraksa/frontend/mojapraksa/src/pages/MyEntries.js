import React, { useState, useEffect } from "react";
import axios from "axios";
import "../styles.css";

const MyEntries = () => {
  const [entries, setEntries] = useState([]);
  const [error, setError] = useState("");
  const userId = sessionStorage.getItem("userId");
  // ...

  useEffect(() => {
    if (!userId) {
      setError("Greška: Korisnik nije prijavljen.");
      return;
    }

    const fetchEntries = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/entries/${userId}`);
        if (Array.isArray(response.data)) {
          setEntries(response.data);
        } else {
          setEntries([]);
          setError("Nema unosa za ovog korisnika.");
        }
      } catch (error) {
        console.error("Greška pri dohvaćanju unosa:", error);
      }
    };

    fetchEntries();
  }, [userId]);

  const handleEdit = (entryId) => {
    window.location.href = `/edit-entry/${entryId}`;
  };

  const handleDelete = async (entryId) => {
    if (window.confirm("Da li ste sigurni da želite izbrisati ovaj unos?")) {
      try {
        await axios.delete(`http://localhost:5000/api/entries/${entryId}`);
        setEntries(entries.filter(entry => entry._id !== entryId));
      } catch (error) {
        console.error("Greška pri brisanju unosa:", error);
      }
    }
  };

  const handleDownloadPDF = async () => {
    try {
      // 1. Dohvati korisničko ime
      const userResponse = await axios.get(`http://localhost:5000/api/auth/${userId}`);
      const username = userResponse.data.username || "korisnik";

      // 2. Dohvati PDF
      const pdfResponse = await axios.get(`http://localhost:5000/api/entries/generate-pdf/${userId}`, {
        responseType: "blob",
      });

      // 3. Kreiraj link za preuzimanje
      const url = window.URL.createObjectURL(new Blob([pdfResponse.data]));
      const link = document.createElement("a");
      link.href = url;

      // Zamijeni razmake sa crtama da naziv fajla bude čist
      const cleanUsername = username.replace(/\s+/g, "-");

      link.setAttribute("download", `Dnevnik Rada - ${cleanUsername}.pdf`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Greška pri preuzimanju PDF-a:", error);
    }
  };

  const formatDate = (isoDate) => {
    const date = new Date(isoDate);
    return date.toLocaleDateString("hr-HR"); // ili en-GB ako hoćeš dd/mm/yyyy
  };

  return (
    <div className="entries-container">
      <h2>Moji Unosi</h2>

      {entries.length > 0 && (
        <button onClick={handleDownloadPDF} className="download-pdf-btn">
          Preuzmi PDF
        </button>
      )}

      {error && <p className="error-message">{error}</p>}

      <div className="entries-list">
        {entries.length > 0 ? (
          entries.map((entry) => (
            <div className="entry-card" key={entry._id}>
              <h3 className="entry-title">{entry.activity}</h3>
              <p><strong>Datum:</strong> {formatDate(entry.date)}</p>
              <div className="time-row">
                <p><strong>Dolazak:</strong> {entry.arrivalTime}</p>
                <p><strong>Odlazak:</strong> {entry.departureTime}</p>
              </div>
              <p className="entry-description"><strong>Opis:</strong> {entry.description}</p>
              <button onClick={() => handleEdit(entry._id)} className="edit-btn">Uredi</button>
              <button onClick={() => handleDelete(entry._id)} className="delete-btn">Izbriši</button>
            </div>
          ))
        ) : (
          <p className="no-entries">Nemate unosa.</p>
        )}
      </div>
    </div>
  );
};

export default MyEntries;
