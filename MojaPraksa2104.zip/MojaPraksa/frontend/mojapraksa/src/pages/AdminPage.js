import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import "../styles.css";

const AdminPage = () => {
  const token = sessionStorage.getItem("token");

  const [view, setView] = useState("users");
  const [dataList, setDataList] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [formData, setFormData] = useState({});
  const [showForm, setShowForm] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const formRef = useRef(null);

  const scrollToForm = () => {
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 0);
  };

  useEffect(() => {
    if (!token) return (window.location.href = "/login");
    fetchAll();
    setSearchTerm("");
    // eslint-disable-next-line
  }, [view]);

  const fetchAll = async () => {
    try {
      if (view === "users") {
        const res = await axios.get("http://localhost:5000/api/auth/users", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setDataList(res.data);
      } else if (view === "companies") {
        const res = await axios.get("http://localhost:5000/api/companies", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setDataList(res.data);
      } else if (view === "interns") {
        const res = await axios.get("http://localhost:5000/api/interns", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setDataList(res.data);
        const comps = await axios.get("http://localhost:5000/api/companies", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCompanies(comps.data);
      }
    } catch (error) {
      console.error("Fetch error:", error);
      alert("Greška pri dohvaćanju podataka.");
    }
  };

  const handleDelete = async (id) => {
    const endpoints = {
      users: "auth/users",
      companies: "companies",
      interns: "interns",
    };
    try {
      await axios.delete(`http://localhost:5000/api/${endpoints[view]}/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchAll();
      alert("Uspješno obrisano.");
    } catch (error) {
      alert(error.response?.data?.message || "Greška");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const endpoints = {
      users: "auth/users",
      companies: "companies",
      interns: "interns",
    };

    let url;
    if (view === "users") {
      url = `http://localhost:5000/api/auth/${showForm === "edit" && selectedItem ? `users/${selectedItem._id}` : "register"}`;
    } else {
      url = `http://localhost:5000/api/${endpoints[view]}${showForm === "edit" && selectedItem ? `/${selectedItem._id}` : ""}`;
    }

    try {
      let dataToSend;
      let headers = {
        Authorization: `Bearer ${token}`,
      };

      if (view === "companies") {
        dataToSend = new FormData();
        for (const key in formData) {
          if (key === "logoFile") {
            dataToSend.append("logo", formData.logoFile);
          } else {
            dataToSend.append(key, formData[key]);
          }
        }
        headers["Content-Type"] = "multipart/form-data";
      } else {
        dataToSend = formData;
        headers["Content-Type"] = "application/json";
      }

      if (showForm === "edit" && selectedItem) {
        await axios.put(url, dataToSend, { headers });
      } else {
        await axios.post(url, dataToSend, { headers });
      }

      alert("Uspješno");
      setFormData({});
      setSelectedItem(null);
      setShowForm(null);
      fetchAll();
    } catch (error) {
      console.error("Greška pri slanju forme:", error);
      alert(error.response?.data?.message || "Greška");
    }
  };

  const filteredDataList =
    view === "interns"
      ? dataList.filter((intern) => {
        const companyName = companies.find((c) => c._id === intern.companyId)?.name || "";
        return (
          [intern.name, intern.email, intern.experience, companyName]
            .join(" ")
            .toLowerCase()
            .includes(searchTerm.toLowerCase())
        );
      })
      : dataList;

  const renderTable = () => {
    if (view === "users") {
      return (
        <>
          <h2>Korisnici</h2>
          <table>
            <thead>
              <tr>
                <th>Korisničko ime</th>
                <th>Email</th>
                <th>Uloga</th>
                <th>Opcije</th>
              </tr>
            </thead>
            <tbody>
              {dataList.map((user) => (
                <tr key={user._id}>
                  <td>{user.username}</td>
                  <td>{user.email}</td>
                  <td>{user.role}</td>
                  <td>
                    <button
                      onClick={() => {
                        setSelectedItem(user);
                        setFormData({
                          username: user.username,
                          email: user.email,
                          password: "",
                          role: user.role,
                        });
                        setShowForm("edit");
                        scrollToForm();
                      }}
                    >
                      Uredi
                    </button>
                    <button onClick={() => handleDelete(user._id)}>Obriši</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      );
    }

    if (view === "companies") {
      return (
        <>
          <h2>Kompanije</h2>
          <table>
            <thead>
              <tr>
                <th>Naziv</th>
                <th>Slika</th>
                <th>Email</th>
                <th>Kratki opis</th>
                <th>Dugi opis</th>
                <th>Opcije</th>
              </tr>
            </thead>
            <tbody>
              {dataList.map((company) => (
                <tr key={company._id}>
                  <td>{company.name}</td>
                  <td>
                    <img src={`http://localhost:5000${company.logo}`} alt="logo" style={{ width: "50px" }} />
                  </td>
                  <td>{company.email}</td>
                  <td>{company.about}</td>
                  <td>{company.detailedDescription}</td>
                  <td>
                    <button
                      onClick={() => {
                        setSelectedItem(company);
                        setFormData(company);
                        setShowForm("edit");
                        scrollToForm();
                      }}
                    >
                      Uredi
                    </button>
                    <button onClick={() => handleDelete(company._id)}>Obriši</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      );
    }

    if (view === "interns") {
      return (
        <>
          <h2>Praktikanti</h2>
          <input
            type="text"
            placeholder="Pretraži praktikante..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ marginBottom: "1rem", padding: "0.5rem", width: "100%" }}
          />
          <table>
            <thead>
              <tr>
                <th>Ime</th>
                <th>Email</th>
                <th>Pozicija</th>
                <th>Kompanija</th>
                <th>Opcije</th>
              </tr>
            </thead>
            <tbody>
              {filteredDataList.map((intern) => (
                <tr key={intern._id}>
                  <td>{intern.name}</td>
                  <td>{intern.email}</td>
                  <td>{intern.experience}</td>
                  <td>{companies.find((c) => c._id === intern.companyId)?.name || "Nepoznato"}</td>
                  <td>
                    <button
                      onClick={() => {
                        setSelectedItem(intern);
                        setFormData(intern);
                        setShowForm("edit");
                        scrollToForm();
                      }}
                    >
                      Uredi
                    </button>
                    <button onClick={() => handleDelete(intern._id)}>Obriši</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      );
    }
  };

  const renderForm = () => {
    if (!showForm) return null;

    return (
      <form onSubmit={handleSubmit}>
        {view === "users" && (
          <>
            <input
              type="text"
              placeholder="Korisničko ime"
              value={formData.username || ""}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
            />
            <input
              type="email"
              placeholder="Email"
              value={formData.email || ""}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
            {showForm === "create" && (
              <input
                type="password"
                placeholder="Lozinka"
                value={formData.password || ""}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
            )}
            <select
              value={formData.role || "user"}
              onChange={(e) => setFormData({ ...formData, role: e.target.value })}
            >
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </>
        )}

        {view === "companies" && (
          <>
            <input
              type="text"
              placeholder="Naziv"
              value={formData.name || ""}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
            <input
              type="file"
              accept="image/png"
              onChange={(e) => setFormData({ ...formData, logoFile: e.target.files[0] })}
            />
            <input
              type="text"
              placeholder="Kratki opis"
              value={formData.about || ""}
              onChange={(e) => setFormData({ ...formData, about: e.target.value })}
            />
            <input
              type="text"
              placeholder="Detaljni opis"
              value={formData.detailedDescription || ""}
              onChange={(e) => setFormData({ ...formData, detailedDescription: e.target.value })}
            />
            <input
              type="email"
              placeholder="Email"
              value={formData.email || ""}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </>
        )}

        {view === "interns" && (
          <>
            <input
              type="text"
              placeholder="Ime"
              value={formData.name || ""}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
            <input
              type="email"
              placeholder="Email"
              value={formData.email || ""}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
            <input
              type="text"
              placeholder="Pozicija"
              value={formData.experience || ""}
              onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
            />
            <select
              value={formData.companyId || ""}
              onChange={(e) => setFormData({ ...formData, companyId: e.target.value })}
            >
              <option value="">Odaberi kompaniju</option>
              {companies.map((comp) => (
                <option key={comp._id} value={comp._id}>
                  {comp.name}
                </option>
              ))}
            </select>
          </>
        )}
        <button type="submit">{showForm === "edit" ? "Spremi izmjene" : "Dodaj novi"}</button>
      </form>
    );
  };

  return (
    <div className="admin-container">
      <h1>Admin Panel</h1>
      <div className="tabs">
        <button onClick={() => { setView("users"); setShowForm(null); }}>Korisnici</button>
        <button onClick={() => { setView("companies"); setShowForm(null); }}>Kompanije</button>
        <button onClick={() => { setView("interns"); setShowForm(null); }}>Praktikanti</button>
      </div>

      <div className="table-section">{renderTable()}</div>

      <button
        onClick={() => {
          setFormData({});
          setSelectedItem(null);
          setShowForm("create");
          scrollToForm();
        }}
      >
        Dodaj {view === "users" ? "korisnika" : view === "companies" ? "kompaniju" : "praktikanta"}
      </button>

      <div className="form-section" ref={formRef}>{renderForm()}</div>
    </div>
  );
};

export default AdminPage;
