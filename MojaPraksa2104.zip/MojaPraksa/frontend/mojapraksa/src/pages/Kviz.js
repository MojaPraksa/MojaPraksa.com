import React, { useState } from "react";
import Quiz from "../components/Quiz";
import Results from "../components/Results";

const Kviz = () => {
    const [results, setResults] = useState(null);

    return (
        <div>
            {!results ? <Quiz setResults={setResults} /> : <Results results={results} resetQuiz={() => setResults(null)} />}
        </div>
    );
};

export default Kviz;
