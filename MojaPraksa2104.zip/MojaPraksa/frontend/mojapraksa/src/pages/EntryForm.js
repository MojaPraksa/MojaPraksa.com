import React, { useState } from "react";
import "../styles.css";

const EntryForm = () => {
    // ...
const [formData, setFormData] = useState({
    userId: sessionStorage.getItem("userId") || "",
    date: "",
    activity: "",
    description: "",
    arrivalTime: "",
    departureTime: ""
});
// ...

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("http://localhost:5000/api/entries", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                alert("Unos je uspešno sačuvan!");
                setFormData({
                    userId: sessionStorage.getItem("userId") || "",
                    date: "",
                    activity: "",
                    description: "",
                    arrivalTime: "",
                    departureTime: ""
                });
            } else {
                alert("Greška prilikom unosa!");
            }
        } catch (error) {
            console.error("Greška:", error);
        }
    };

    return (
        <div className="entry-form-container">
            <div className="form-box">
                <h2 className="form-title">Dodaj novi unos</h2>
                <form onSubmit={handleSubmit} className="form">
                    <div className="form-field">
                        <label htmlFor="date">Datum:</label>
                        <input type="date" name="date" value={formData.date} onChange={handleChange} required />
                    </div>

                    <div className="form-field">
                        <label htmlFor="activity">Aktivnost:</label>
                        <input type="text" name="activity" value={formData.activity} onChange={handleChange} required />
                    </div>

                    <div className="form-field">
                        <label htmlFor="description">Opis:</label>
                        <textarea name="description" value={formData.description} onChange={handleChange}></textarea>
                    </div>

                    <div className="form-fields-group">
                        <div className="form-field">
                            <label htmlFor="arrivalTime">Vrijeme dolaska:</label>
                            <input type="time" name="arrivalTime" value={formData.arrivalTime} onChange={handleChange} required />
                        </div>
                        <div className="form-field">
                            <label htmlFor="departureTime">Vrijeme odlaska:</label>
                            <input type="time" name="departureTime" value={formData.departureTime} onChange={handleChange} required />
                        </div>
                    </div>

                    <button type="submit" className="submit-button">Sačuvaj unos</button>
                </form>
            </div>
        </div>
    );
};

export default EntryForm;
