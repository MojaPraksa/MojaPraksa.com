import React, { useEffect, useState } from "react";
import Hero from "../components/Hero";
import Firme from "../components/Firme";
import ONama from "../components/ONama";
import NasaEkipa from "../components/NasaEkipa";

const LandingPage = () => {
  const [companies, setCompanies] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/companies") // Prilagodi URL ako treba
      .then((res) => res.json())
      .then((data) => setCompanies(data))
      .catch((err) => console.error("Greška pri dohvaćanju kompanija:", err));
  }, []);

  return (
    <div className="w-full">
      <div className="mt-16">
        <Hero />
        <div id="firme">
          <Firme companies={companies} />
          <ONama />
          <NasaEkipa />
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
