import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import ApplyForm from '../components/ApplyForm';
import InternsList from '../components/InternsList';
import "../styles.css"; // Importiraj stilove

const CompanyPage = () => {
    const { id } = useParams();
    const [company, setCompany] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        axios.get(`http://localhost:5000/api/companies/${id}`)
            .then(response => {
                setCompany(response.data);
                setError(null);
            })
            .catch(error => {
                setError('Greška pri dohvaćanju podataka o kompaniji.');
                console.error(error);
            });
    }, [id]);

    if (error) return <p>{error}</p>;
    if (!company) return <p>Učitavanje...</p>;

    return (
        <div className="company-page-container">
            {/* Company Header */}
            <div className="company-header">
                <div className="company-header-content">
                    <img
                        src={`http://localhost:5000${company.logo}`}
                        alt={company.name}
                        className="company-logo"
                    />

                    <h1 className="company-name">{company.name}</h1>
                </div>
                <p className="company-description">{company.detailedDescription}</p>
            </div>

            {/* Interns List */}
            <InternsList companyId={id} />

            {/* Application Form */}
            <div className="application-form-container">
                <ApplyForm companyId={id} />
            </div>
        </div>
    );
};

export default CompanyPage;
